<script>
  import { Router } from '@roxi/routify';
  import { routes } from '../.routify/routes';
</script>

<Router {routes} />

<style global>
  @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@400;700&display=swap');
  @import '../assets/global.css';
</style>
