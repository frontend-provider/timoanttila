<div id="blog">
	<div id="content">
		Sisältö
		<slot />
	</div>
	<aside>
		<div>Esittely</div>
	</aside>
</div>
