<script>
	import { lang } from '../../components/lang';
	lang.set('fi-fi');
</script>

<slot />
